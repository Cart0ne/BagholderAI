# Handoff: Dashboard §2 — Bot cards live (brains + traders)

## Overview

All five bot cards on `/dashboard` §2 go from static description cards to
**live horizontal rows with real parameters**, stacked in data-flow order.
Two groups, same row grammar:

```
THE TRADERS:  Trend Follower ──tf picks, grid manages──▶ Grid Bot (+ managed coins)
THE BRAINS:   NewsKeeper ──barometer (shadow)──▶ Sentinel ──regime──▶ Sherpa
```

This replaces the current TF/Grid `.instruments` block (side-by-side + holdings
strip), the `.duo` Sentinel/Sherpa block, and the static NewsKeeper card in
`src/pages/dashboard.astro`.

## About the design files

The files in `reference/` are **design references created in HTML** — they show
the intended look, not production code. The task is to **recreate this design
in `web_astro`** (Astro + Tailwind v4) using the site's existing patterns:
tokens from `src/styles/global.css`, mock-fallback + live-wiring split per
STYLEGUIDE §9, existing mascot components. **Never copy a literal hex from the
reference into the codebase — use the token** (STYLEGUIDE §5).

## Fidelity

**High-fidelity.** Colors, type sizes, spacing and copy are final. Recreate
pixel-perfectly with Tailwind utilities mapped to the tokens listed below.

## Prerequisite: one new token

NewsKeeper has no bot accent token yet. Add to `@theme` in `global.css`:

```css
--color-bot-news: #6E68B0;        /* lilla family, same hue as --color-cc */
--color-bot-news-soft: #E2E0F2;
```

Document it in STYLEGUIDE §5 (per §20.5). Mascots keep their **bright brand
colors** (NewsKeeper `#a855f7` etc.) — only the card chrome uses the pastel token.

## Layout — the row card (shared grammar)

One `<article>` per bot, inside the standard `max-w-4xl` container.

- **Brains** desktop grid: `grid-template-columns: 134px 252px 1fr; gap: 20px`
  (mascot plate | identity | live rail)
- **Traders** desktop grid: `grid-template-columns: 134px 212px 1fr 186px;
  gap: 18px` (mascot plate | identity | core numbers | coins column)

```
┌──────────────────────────────────────────────────────────────┐
│ ▌ [mascot    ] [identity column 252px] │ [live rail (1fr)]   │
│   [plate     ]  name + LIVE pill       │  bot-specific       │
│   [134px     ]  role (italic)          │  live widgets       │
│              ]  description            │                     │
│              ]  ● cadence (mt-auto)    │                     │
└──────────────────────────────────────────────────────────────┘
```

Card shell (all three rows identical):
- `bg-surface`, `border border-border`, **`border-left: 4px solid <bot accent>`**,
  `rounded-[18px]`, `shadow-sticker-sm`, `p-[18px]`
- Mascot plate: `bg-panel border border-border-soft rounded-[14px] p-2.5`,
  mascot image 86×112 (object-fit contain), bottom-aligned
- Live rail: `border-l border-border-soft pl-5`, flex column,
  `justify-content: center`, `gap: 10px`

Identity column:
- Name row (flex, gap 8): 4×14px rounded bar in bot accent · name
  `font-mono 12px font-bold uppercase tracking-[0.08em]` in bot accent ·
  LIVE pill (`font-mono text-[9px] uppercase tracking-[0.16em] text-pos
  bg-pos-soft border border-pos/25 rounded-full px-2 py-0.5` + 5px pos dot)
- Role: `italic text-[12px] text-text-muted` — "News watcher" / "Risk
  officer" / "Parameter tuner"
- Description: `text-[12.5px] leading-[1.5] text-text-dim`
- Cadence line pinned to bottom (`mt-auto`): `font-mono text-[10px]
  text-text-muted` + 5px pos dot

### Flow connectors (between rows)

Left-indented 56px, flex row gap 10:
- 14×34 SVG: 2px vertical line + solid triangle, both `border` token color
- Label `font-mono text-[9.5px] font-bold uppercase tracking-[0.16em]
  text-primary`: "tf picks, grid manages" / "barometer" / "regime"
- The barometer connector also carries a **"shadow" pill**: `font-mono
  text-[8.5px] uppercase text-warn bg-warn-soft border border-warn/25
  rounded-full px-2 py-px`

## The traders — TF + Grid rows

Section header: `§ 2 · Instruments — the traders` with right aside
`tf picks → grid manages`. Order: Trend Follower → connector → Grid Bot →
"Net realized profit" bar.

### Identity column (both)

- Name row: accent bar + name + LIVE pill (same as brains)
- Meta: `font-mono text-[10px] text-text-dim` — "— $100 · live · Tier 1-2" /
  "— $500 · live"
- Tagline italic: "The breakout hunter" / "The cash machine"
- Bottom (`mt-auto`): `font-mono text-[10px] text-text-muted` —
  "Day N · Cash to reinvest: **$X**" (value in `text-text`, bold)

### Core column (border-l border-border-soft, pl-[18px], flex col gap 10)

1. "Net worth" mono label + value row: `font-display font-extrabold
   text-[30px]` + change `font-mono text-[11px]` in pos/neg
2. **7d net-worth sparkline** — full column width, own line (NOT beside the
   number; it overflows). Inline SVG `viewBox="0 0 100 30"
   preserveAspectRatio="none"`, height 30px: area polygon at `opacity:.12`,
   1.6px polyline, 2.2r dot on the last point — all in the bot accent token
   (`bot-tf` / `bot-grid`). Caption right-aligned: `font-mono text-[8px]
   uppercase tracking-[0.1em] text-text-muted` — "7d net worth".
   Implementation: compute points in `dashboard-live.ts` from the last 7
   daily net-worth snapshots; no Chart.js needed for these.
3. Triple stat (border-t, pt-2.5, grid 3 cols): mono 9px labels
   Unrealized / Fees paid / Skim; values `font-mono font-bold text-[12.5px]`
   in pos/neg by sign.
4. Cash row pinned bottom (`mt-auto`): mono 10px "Cash … NN%" + 7px
   rounded allocation bar (track = `bg` token; invested segments in coin
   colors: BONK `bot-tf`, BTC `primary`, SOL `neu`; remainder = cash).

### Coins column (186px, flex col gap 8)

- Mono 9px label: "Managed coins" (Grid) / "Open positions" (TF)
- **Grid**: one chip per coin — `bg-panel border border-border-soft
  rounded-[12px] px-3 py-[9px]`. Row 1: symbol (`font-mono text-[9.5px]
  font-bold tracking-[0.1em]`, coin color) + price (`font-display
  font-extrabold text-[15px]`). Row 2: "avg $X" (`font-mono text-[8.5px]
  text-text-muted`) + change (`font-mono text-[9.5px] font-bold` pos/neg).
  Coin colors: BONK `bot-tf` · BTC `primary` · SOL `neu`.
- **TF (no open positions)**: honest empty state — dashed `border` box,
  rounded 12, centered `font-mono text-[9.5px] text-text-muted` copy:
  "None — 100% cash. Scanning Tier 1-2 for breakouts." When TF opens a
  position, render the same chips as Grid.

### Net realized bar

Full-width white card below Grid row: mono uppercase label "Net realized
profit (post-fees)" left, value `font-display font-extrabold text-[20px]
text-pos` right. Keep existing live id if one exists.

## The brains — per-bot live widgets (the right rail)

### NewsKeeper (`--ac: var(--color-bot-news)`)

1. Label "Latest classified headlines" (`font-mono text-[10px] font-bold
   uppercase tracking-[0.14em] text-text-muted`)
2. Headline list (4 items, flex column gap 7): 7px severity dot
   (`neg` = bearish, `pos` = bullish, `text-muted` = neutral) + headline
   `text-[12.5px] leading-[1.45] text-text-dim`
3. Barometer box: `bg-panel border border-border-soft rounded-[12px]
   px-4 py-3`, label left, value right in `font-display font-extrabold
   text-[18px]` — color `text-neg` (Bearish) / `text-pos` (Bullish) /
   `text-text-muted` (Neutral)

### Sentinel (`--ac: var(--color-bot-sentinel)`)

1. Fear/Greed gauge — 5 equal segments in a `rounded-[10px] overflow-hidden
   border border-border` flex row. Each: `font-mono text-[8.5px] uppercase
   tracking-[0.06em] py-[7px] text-center`.
   Inactive fills (soft): primary-soft · neu-soft · border-soft · warn-soft ·
   neg-soft, text `text-muted`. **Active segment**: solid token fill
   (primary / neu / text-muted / warn / neg), white bold text,
   `inset 0 0 0 2px` ring at ~20% ink.
2. Two score boxes side by side (flex gap 10, each flex-1): `bg-panel
   border border-border-soft rounded-[12px] px-3.5 py-2.5`. Mono label,
   5px progress track (`bg-border`, fill width = value%, **Risk fill = neg,
   Opportunity fill = pos**), value `font-display font-extrabold text-[22px]`.
3. Strip: `font-mono text-[10.5px] text-text-dim` —
   "₿ BTC +0.51% (1h) · Funding −0.005%"

### Sherpa (`--ac: var(--color-bot-sherpa)`)

1. Top row (flex, space-between): regime badge + right-aligned mono
   micro-label "grid / step / window" (9px).
   Regime badge: shield glyph + text, `font-mono text-[11.5px] font-bold
   uppercase tracking-[0.08em] rounded-full px-3.5 py-1.5`.
   Color by regime: Defensive → `text-primary bg-primary-soft`;
   Neutral → `text-neu bg-neu-soft`; Aggressive → `text-warn bg-warn-soft`.
2. Per-coin table (no wrapper border — rows divided by `border-t
   border-border-soft`): grid `52px 1fr auto`, `py-2`.
   Symbol `font-mono text-[11px] font-bold text-text` · posture
   `text-[11.5px] text-text-dim` · params `font-mono text-[10.5px]
   font-bold text-text-muted whitespace-nowrap` (e.g. "2.5 / 1.0 / 4h").
3. "Last adjustment: X min ago" lives in the **cadence slot** of the
   identity column (id `sherpa-last`).

## Mascots

Use the **existing site mascot components** (`BotMascot` for TF/Grid,
`NewsKeeperMascot`, `SentinelMascot`, `SherpaMascotV2`) with their bright brand
colors — same as
the current dashboard cards. The SVGs in `reference/` are only for viewing the
mockup; don't import them if the components already exist. All three bots are
now **LIVE** — no more locked/dim variants, no more `DRY_RUN` pill on Sherpa.

## Responsive behavior

- Brains ≤720px / traders ≤820px: row collapses to `grid-template-columns:
  96px 1fr` (mascot 64×84); live rail / core column spans full width below
  (`grid-column: 1/-1`, `border-t border-border-soft pt-3.5` instead of
  border-left); traders' coins column also spans full width as a 3-col chip
  grid (1-col ≤480px); connectors indent 36px.
- ≤440px (brains): single column; mascot plate shrinks to 96px wide.
- Test at 375 / 768 / 1280 per STYLEGUIDE §17.

## Live data wiring (STYLEGUIDE §9 — follow it exactly)

Mock fallback rendered server-side from `src/data/dashboard-mock.ts`;
live swap in `src/scripts/dashboard-live.ts`. No fetch in frontmatter,
try/catch silente con `console.warn`.

Suggested mock shapes to add:

```ts
export const mockTraders = {
  tf: {
    nw: 100.0, chg: 0.0, chgPct: 0.0,
    unrealized: 0.0, fees: 0.0, skim: 0.0,
    cashPct: 100, reinvest: 100.0, day: 8,
    spark7d: [100, 100, 100, 100, 100, 100, 100],
    positions: [],            // [] → render the dashed empty state
  },
  grid: {
    nw: 504.38, chg: 4.38, chgPct: 0.88,
    unrealized: -3.27, fees: -1.95, skim: 4.4944,
    cashPct: 64, reinvest: 318.09, day: 8,
    spark7d: [500, 501.5, 498.2, 495.8, 497.4, 501.1, 504.38],
    alloc: [{ sym: "BONK", pct: 26 }, { sym: "SOL", pct: 10 }],
    coins: [
      { sym: "BONK", value: 142.87, avg: "$0.00000456", chg: -3.61, chgPct: -2.47 },
      { sym: "BTC",  value: 0.23,   avg: "$62409.03",   chg: 0.0,   chgPct: 2.09 },
      { sym: "SOL",  value: 40.65,  avg: "$66.33",      chg: 0.34,  chgPct: 0.83 },
    ],
  },
};

export const mockBrains = {
  newskeeper: {
    headlines: [ // newest 4
      { text: "SEC delays spot ETH ETF decision to Q3", sentiment: "neg" },
      { text: "BlackRock Bitcoin fund sees $274M inflows", sentiment: "pos" },
      { text: "Solana DEX volume holds steady at $2.1B", sentiment: "neu" },
      { text: "Binance faces new regulatory probe in EU", sentiment: "neg" },
    ],
    barometer24h: "Bearish" as "Bearish" | "Neutral" | "Bullish",
  },
  sentinel: {
    fearGreedBand: 0,        // 0..4 → extreme fear … extreme greed
    risk: 20,                // 0..100
    opportunity: 25,         // 0..100
    btc1h: "+0.51%",
    funding: "−0.005%",
  },
  sherpa: {
    regime: "Defensive" as "Defensive" | "Neutral" | "Aggressive",
    coins: [
      { sym: "BTC",  posture: "buy tight, sell fast, wait long", params: "2.5 / 1.0 / 4h" },
      { sym: "SOL",  posture: "buy tight, sell fast, wait long", params: "3.0 / 1.6 / 4h" },
      { sym: "BONK", posture: "buy tight, sell fast, wait long", params: "3.0 / 1.8 / 4h" },
    ],
    lastAdjustment: "2 min ago",
  },
};
```

Element ids already stamped in the reference markup:

**Traders** (`Trade Cards Reference.html`) — if `dashboard.astro` already has
live ids for these numbers, **keep the existing ids** and just move the markup:

| id | content |
|---|---|
| `tf-nw` / `tf-chg` | TF net worth / change (use `__updateLiveStat` for nw) |
| `tf-unrl` / `tf-fees` / `tf-skim` | TF triple stat |
| `tf-cash-pct` / `tf-cash-bar` | cash % / allocation bar segments |
| `tf-reinvest` / `tf-spark` / `tf-positions` | reinvest · sparkline svg · positions box |
| `grid-*` | same set for Grid (`grid-nw`, `grid-chg`, …) |
| `grid-coins` | coin chips container (rebuilt by JS) |
| `net-realized` | net realized profit value |

**Brains** (`Brain Cards Reference.html`):

| id | content |
|---|---|
| `nk-headlines` | headline list container (rebuilt by JS) |
| `nk-barometer` | barometer value (text + color class swap) |
| `sent-gauge` | gauge container (active segment swap) |
| `sent-risk` / `sent-risk-bar` | risk value / bar width |
| `sent-opp` / `sent-opp-bar` | opportunity value / bar width |
| `sent-strip` | BTC + funding strip |
| `sherpa-regime` | regime badge (text + color class swap) |
| `sherpa-coins` | per-coin rows container (rebuilt by JS) |
| `sherpa-last` | "Last adjustment: …" |

⚠️ **STYLEGUIDE §16 / lesson S82**: `nk-headlines`, `sherpa-coins`, `grid-coins`
and the sparkline/alloc-bar children are rebuilt via `createElement` — those
nodes won't carry `data-astro-cid-*`.
Use `<style is:global>` with component-prefixed classes (`brain-headline`,
`brain-coin`, …) or put the classes in `global.css`. Don't use
`window.__updateLiveStat` on the gauge/badge (they're not numeric counters);
plain class swaps are fine.

## Design tokens used

Backgrounds `bg / surface / panel` · borders `border / border-soft` · text
`text / text-dim / text-muted` · accents `primary(-soft) / pos(-soft) /
neg(-soft) / neu(-soft) / warn(-soft)` · bots `bot-sentinel / bot-sherpa /
bot-news (NEW)` · fonts `display (Bricolage) / sans (Inter) / mono
(JetBrains)` · shadow `sticker-sm` · radii: card 18 / inset boxes 12–14 /
pills 999.

## Files

- `reference/Trade Cards Reference.html` — **the traders contract**: TF + Grid
  rows, sparkline, coin chips, empty state, responsive (resize the window)
- `reference/Brain Cards Reference.html` — **the brains contract**: NewsKeeper,
  Sentinel, Sherpa rows + connectors, responsive
- `reference/*.svg` — mascot art used by the reference pages only
- In the design project root: `Dashboard Brain Cards.html` (design canvas with
  all options incl. the discarded 3-column variant), built from
  `brain-cards-shared.jsx`, `brain-cards-horizontal.jsx`,
  `trade-cards-horizontal.jsx`, `brain-cards-columns.jsx`

## Checklist for CC

- [ ] Add `--color-bot-news(-soft)` to `global.css` + STYLEGUIDE §5
- [ ] §2 — traders: replace the side-by-side `.instruments` block + holdings
      strip with the two horizontal rows (TF → Grid) + connector + net-realized bar
- [ ] Sparkline: 7d net-worth history wired in `dashboard-live.ts` (inline SVG)
- [ ] TF empty state when `positions` is `[]`; chips when it opens positions
- [ ] §2 — brains: replace static NewsKeeper/Sentinel/Sherpa cards with the
      three rows + 2 connectors (order: NewsKeeper → Sentinel → Sherpa)
- [ ] Sherpa status pill: `dry_run` → `live`
- [ ] Mock shapes in `dashboard-mock.ts`, wiring in `dashboard-live.ts`
- [ ] `is:global` styles for JS-rebuilt lists (headlines, coins, chips, bars)
- [ ] Compare side-by-side against both reference pages at 1280 px
- [ ] Test 375 / 768 / 1280 · `npm run build` passes
