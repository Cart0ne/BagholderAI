# Handoff: Dashboard §2 — Brain bot cards (live)

## Overview

The three "brain" bots (NewsKeeper, Sentinel, Sherpa) on `/dashboard` §2 go
from static description cards to **live cards with real parameters**, laid out
as **full-width horizontal rows stacked in data-flow order**:

```
NewsKeeper ──barometer (shadow)──▶ Sentinel ──regime──▶ Sherpa
```

This replaces the current `.duo` Sentinel/Sherpa block and the static
NewsKeeper card at the bottom of §2 in `src/pages/dashboard.astro`.

## About the design files

The files in `reference/` are **design references created in HTML** — they show
the intended look, not production code. The task is to **recreate this design
in `web_astro`** (Astro + Tailwind v4) using the site's existing patterns:
tokens from `src/styles/global.css`, mock-fallback + live-wiring split per
STYLEGUIDE §9, existing mascot components. **Never copy a literal hex from the
reference into the codebase — use the token** (STYLEGUIDE §5).

## Fidelity

**High-fidelity.** Colors, type sizes, spacing and copy are final. Recreate
pixel-perfectly with Tailwind utilities mapped to the tokens listed below.

## Prerequisite: one new token

NewsKeeper has no bot accent token yet. Add to `@theme` in `global.css`:

```css
--color-bot-news: #6E68B0;        /* lilla family, same hue as --color-cc */
--color-bot-news-soft: #E2E0F2;
```

Document it in STYLEGUIDE §5 (per §20.5). Mascots keep their **bright brand
colors** (NewsKeeper `#a855f7` etc.) — only the card chrome uses the pastel token.

## Layout — the row card

One `<article>` per bot, inside the standard `max-w-4xl` container.
Desktop grid: `grid-template-columns: 134px 252px 1fr; gap: 20px`.

```
┌──────────────────────────────────────────────────────────────┐
│ ▌ [mascot    ] [identity column 252px] │ [live rail (1fr)]   │
│   [plate     ]  name + LIVE pill       │  bot-specific       │
│   [134px     ]  role (italic)          │  live widgets       │
│              ]  description            │                     │
│              ]  ● cadence (mt-auto)    │                     │
└──────────────────────────────────────────────────────────────┘
```

Card shell (all three rows identical):
- `bg-surface`, `border border-border`, **`border-left: 4px solid <bot accent>`**,
  `rounded-[18px]`, `shadow-sticker-sm`, `p-[18px]`
- Mascot plate: `bg-panel border border-border-soft rounded-[14px] p-2.5`,
  mascot image 86×112 (object-fit contain), bottom-aligned
- Live rail: `border-l border-border-soft pl-5`, flex column,
  `justify-content: center`, `gap: 10px`

Identity column:
- Name row (flex, gap 8): 4×14px rounded bar in bot accent · name
  `font-mono 12px font-bold uppercase tracking-[0.08em]` in bot accent ·
  LIVE pill (`font-mono text-[9px] uppercase tracking-[0.16em] text-pos
  bg-pos-soft border border-pos/25 rounded-full px-2 py-0.5` + 5px pos dot)
- Role: `italic text-[12px] text-text-muted` — "News watcher" / "Risk
  officer" / "Parameter tuner"
- Description: `text-[12.5px] leading-[1.5] text-text-dim`
- Cadence line pinned to bottom (`mt-auto`): `font-mono text-[10px]
  text-text-muted` + 5px pos dot

### Flow connectors (between rows)

Left-indented 56px, flex row gap 10:
- 14×34 SVG: 2px vertical line + solid triangle, both `border` token color
- Label `font-mono text-[9.5px] font-bold uppercase tracking-[0.16em]
  text-primary`: "barometer" / "regime"
- The barometer connector also carries a **"shadow" pill**: `font-mono
  text-[8.5px] uppercase text-warn bg-warn-soft border border-warn/25
  rounded-full px-2 py-px`

## Per-bot live widgets (the right rail)

### NewsKeeper (`--ac: var(--color-bot-news)`)

1. Label "Latest classified headlines" (`font-mono text-[10px] font-bold
   uppercase tracking-[0.14em] text-text-muted`)
2. Headline list (4 items, flex column gap 7): 7px severity dot
   (`neg` = bearish, `pos` = bullish, `text-muted` = neutral) + headline
   `text-[12.5px] leading-[1.45] text-text-dim`
3. Barometer box: `bg-panel border border-border-soft rounded-[12px]
   px-4 py-3`, label left, value right in `font-display font-extrabold
   text-[18px]` — color `text-neg` (Bearish) / `text-pos` (Bullish) /
   `text-text-muted` (Neutral)

### Sentinel (`--ac: var(--color-bot-sentinel)`)

1. Fear/Greed gauge — 5 equal segments in a `rounded-[10px] overflow-hidden
   border border-border` flex row. Each: `font-mono text-[8.5px] uppercase
   tracking-[0.06em] py-[7px] text-center`.
   Inactive fills (soft): primary-soft · neu-soft · border-soft · warn-soft ·
   neg-soft, text `text-muted`. **Active segment**: solid token fill
   (primary / neu / text-muted / warn / neg), white bold text,
   `inset 0 0 0 2px` ring at ~20% ink.
2. Two score boxes side by side (flex gap 10, each flex-1): `bg-panel
   border border-border-soft rounded-[12px] px-3.5 py-2.5`. Mono label,
   5px progress track (`bg-border`, fill width = value%, **Risk fill = neg,
   Opportunity fill = pos**), value `font-display font-extrabold text-[22px]`.
3. Strip: `font-mono text-[10.5px] text-text-dim` —
   "₿ BTC +0.51% (1h) · Funding −0.005%"

### Sherpa (`--ac: var(--color-bot-sherpa)`)

1. Top row (flex, space-between): regime badge + right-aligned mono
   micro-label "grid / step / window" (9px).
   Regime badge: shield glyph + text, `font-mono text-[11.5px] font-bold
   uppercase tracking-[0.08em] rounded-full px-3.5 py-1.5`.
   Color by regime: Defensive → `text-primary bg-primary-soft`;
   Neutral → `text-neu bg-neu-soft`; Aggressive → `text-warn bg-warn-soft`.
2. Per-coin table (no wrapper border — rows divided by `border-t
   border-border-soft`): grid `52px 1fr auto`, `py-2`.
   Symbol `font-mono text-[11px] font-bold text-text` · posture
   `text-[11.5px] text-text-dim` · params `font-mono text-[10.5px]
   font-bold text-text-muted whitespace-nowrap` (e.g. "2.5 / 1.0 / 4h").
3. "Last adjustment: X min ago" lives in the **cadence slot** of the
   identity column (id `sherpa-last`).

## Mascots

Use the **existing site mascot components** (`NewsKeeperMascot`,
`SentinelMascot`, `SherpaMascotV2`) with their bright brand colors — same as
the current dashboard cards. The SVGs in `reference/` are only for viewing the
mockup; don't import them if the components already exist. All three bots are
now **LIVE** — no more locked/dim variants, no more `DRY_RUN` pill on Sherpa.

## Responsive behavior

- ≤720px: row collapses to `grid-template-columns: 96px 1fr` (mascot 64×84);
  live rail spans full width below (`grid-column: 1/-1`,
  `border-t border-border-soft pt-3.5` instead of border-left);
  connectors indent 36px.
- ≤440px: single column; mascot plate shrinks to 96px wide.
- Test at 375 / 768 / 1280 per STYLEGUIDE §17.

## Live data wiring (STYLEGUIDE §9 — follow it exactly)

Mock fallback rendered server-side from `src/data/dashboard-mock.ts`;
live swap in `src/scripts/dashboard-live.ts`. No fetch in frontmatter,
try/catch silente con `console.warn`.

Suggested mock shapes to add:

```ts
export const mockBrains = {
  newskeeper: {
    headlines: [ // newest 4
      { text: "SEC delays spot ETH ETF decision to Q3", sentiment: "neg" },
      { text: "BlackRock Bitcoin fund sees $274M inflows", sentiment: "pos" },
      { text: "Solana DEX volume holds steady at $2.1B", sentiment: "neu" },
      { text: "Binance faces new regulatory probe in EU", sentiment: "neg" },
    ],
    barometer24h: "Bearish" as "Bearish" | "Neutral" | "Bullish",
  },
  sentinel: {
    fearGreedBand: 0,        // 0..4 → extreme fear … extreme greed
    risk: 20,                // 0..100
    opportunity: 25,         // 0..100
    btc1h: "+0.51%",
    funding: "−0.005%",
  },
  sherpa: {
    regime: "Defensive" as "Defensive" | "Neutral" | "Aggressive",
    coins: [
      { sym: "BTC",  posture: "buy tight, sell fast, wait long", params: "2.5 / 1.0 / 4h" },
      { sym: "SOL",  posture: "buy tight, sell fast, wait long", params: "3.0 / 1.6 / 4h" },
      { sym: "BONK", posture: "buy tight, sell fast, wait long", params: "3.0 / 1.8 / 4h" },
    ],
    lastAdjustment: "2 min ago",
  },
};
```

Element ids already stamped in the reference markup:

| id | content |
|---|---|
| `nk-headlines` | headline list container (rebuilt by JS) |
| `nk-barometer` | barometer value (text + color class swap) |
| `sent-gauge` | gauge container (active segment swap) |
| `sent-risk` / `sent-risk-bar` | risk value / bar width |
| `sent-opp` / `sent-opp-bar` | opportunity value / bar width |
| `sent-strip` | BTC + funding strip |
| `sherpa-regime` | regime badge (text + color class swap) |
| `sherpa-coins` | per-coin rows container (rebuilt by JS) |
| `sherpa-last` | "Last adjustment: …" |

⚠️ **STYLEGUIDE §16 / lesson S82**: `nk-headlines` and `sherpa-coins` are
rebuilt via `createElement` — those nodes won't carry `data-astro-cid-*`.
Use `<style is:global>` with component-prefixed classes (`brain-headline`,
`brain-coin`, …) or put the classes in `global.css`. Don't use
`window.__updateLiveStat` on the gauge/badge (they're not numeric counters);
plain class swaps are fine.

## Design tokens used

Backgrounds `bg / surface / panel` · borders `border / border-soft` · text
`text / text-dim / text-muted` · accents `primary(-soft) / pos(-soft) /
neg(-soft) / neu(-soft) / warn(-soft)` · bots `bot-sentinel / bot-sherpa /
bot-news (NEW)` · fonts `display (Bricolage) / sans (Inter) / mono
(JetBrains)` · shadow `sticker-sm` · radii: card 18 / inset boxes 12–14 /
pills 999.

## Files

- `reference/Brain Cards Reference.html` — **open this in a browser**; the
  contract to match, including responsive behavior (resize the window)
- `reference/newskeeper.svg`, `sentinel.svg`, `sherpa.svg` — mascot art used
  by the reference page only
- In the design project root: `Dashboard Brain Cards.html` (design canvas
  with Option A + discarded Option B), built from `brain-cards-shared.jsx`,
  `brain-cards-horizontal.jsx`, `brain-cards-columns.jsx`

## Checklist for CC

- [ ] Add `--color-bot-news(-soft)` to `global.css` + STYLEGUIDE §5
- [ ] Replace static NewsKeeper/Sentinel/Sherpa cards in `dashboard.astro`
      with the three rows + 2 connectors (order: NewsKeeper → Sentinel → Sherpa)
- [ ] Sherpa status pill: `dry_run` → `live`
- [ ] Mock shapes in `dashboard-mock.ts`, wiring in `dashboard-live.ts`
- [ ] `is:global` styles for JS-rebuilt lists (headlines, coins)
- [ ] Compare side-by-side against `Brain Cards Reference.html` at 1280 px
- [ ] Test 375 / 768 / 1280 · `npm run build` passes
